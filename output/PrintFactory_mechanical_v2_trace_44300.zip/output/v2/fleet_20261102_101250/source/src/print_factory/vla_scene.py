"""Transfer public LIBERO geometry and poses into Genesis; no model or teacher actions here."""
from dataclasses import dataclass
from pathlib import Path
import json
import xml.etree.ElementTree as ET
import numpy as np
from scipy.spatial.transform import Rotation
from .vla_policy import make_state, validate_action
from .scene import numpy, ROOT


def transform(pos, quat_wxyz):
    t=np.eye(4)
    q=np.asarray(quat_wxyz)
    t[:3,:3]=Rotation.from_quat(q[[1,2,3,0]]).as_matrix()
    t[:3,3]=pos
    return t


def prepare_genesis_xml(source, target):
    root=ET.parse(source).getroot()
    # The actual native camera has all geom groups enabled. Match its colored robot surfaces.
    # Only the coplanar table collision overlay differs in draw order; keep its physics but
    # draw the textured visual twin. This avoids an opaque yellow tabletop in Genesis.
    for geom in root.findall('.//geom'):
        collidable=int(geom.get('contype','1')) or int(geom.get('conaffinity','1'))
        if collidable and geom.get('name')=='table_collision':
            geom.set('group','3')
    # Convert repeated identical cube-face files to the equivalent planar texture mapping.
    for texture in root.findall('.//texture'):
        if texture.get('type')=='cube' and texture.get('file'):
            texture.set('type','2d')
    ET.ElementTree(root).write(target,encoding='unicode')
    return Path(target)


@dataclass
class VLAScene:
    scene: object
    world: object
    agent: object
    wrist: object
    ee: object
    arm_idx: list
    gripper_idx: list
    reference: dict
    gripper_command: object = None
    osc: object = None

    def state(self):
        # Native LIBERO position uses grip_site; quaternion uses the robot hand body.
        q=numpy(self.world.get_link('robot0_right_hand').get_quat())
        return make_state(numpy(self.ee.get_pos()),q[[1,2,3,0]],
                          numpy(self.world.get_dofs_position(self.gripper_idx)))

    def observe(self):
        self.wrist.move_to_attach()
        return self.agent.render()[0][:,::-1].copy(),self.wrist.render()[0][:,::-1].copy()

    def joint_poses(self):
        q=numpy(self.world.get_qpos())
        return {j['name']:q[self.world.get_joint(j['name']).qs_idx_local].tolist()
                for j in self.reference['joint_qpos']}

    def hold(self):
        idx=self.arm_idx+self.gripper_idx
        self.world.control_dofs_position(self.world.get_dofs_position(idx),idx)

    def step_action(self, action):
        action=np.clip(validate_action(action),-1,1)
        if self.osc is not None:
            indices=self.arm_idx+self.gripper_idx
            self.osc.update(numpy(self.world.get_dofs_position(indices)),numpy(self.world.get_dofs_velocity(indices)))
            self.osc.goal(action)
            if self.gripper_command is None:self.gripper_command=np.array([.04,-.04])
            for _ in range(25):
                self.gripper_command+=np.array([-1,1])*.0002*np.sign(action[-1])
                self.gripper_command=np.clip(self.gripper_command,[0,-.04],[.04,0])
                self.world.control_dofs_position(self.gripper_command,self.gripper_idx)
                self.osc.update(numpy(self.world.get_dofs_position(indices)),numpy(self.world.get_dofs_velocity(indices)))
                self.world.control_dofs_force(self.osc.torque(),self.arm_idx)
                self.scene.step()
            return
        current_pos=numpy(self.ee.get_pos())
        current_quat=numpy(self.ee.get_quat())
        rotation=Rotation.from_rotvec(action[3:6]*.5)*Rotation.from_quat(current_quat[[1,2,3,0]])
        target_quat=rotation.as_quat()[[3,0,1,2]]
        target_pos=current_pos+action[:3]*.05
        solution=self.world.inverse_kinematics(self.ee,pos=target_pos,quat=target_quat,
            dofs_idx_local=self.arm_idx,max_samples=1,max_solver_iters=30)
        # Returned generalized coordinates include free bodies; map only the seven arm joints.
        qidx=[self.world.get_joint(f'robot0_joint{i}').qs_idx_local[0] for i in range(1,8)]
        self.world.control_dofs_position(solution[qidx],self.arm_idx)
        # Match Robosuite PandaGripper's incremental +-speed action interface.
        if self.gripper_command is None:
            self.gripper_command=np.array([.04,-.04])
        # Upstream integrates normalized speed.01 at25 physics substeps per20Hz policy step;
        # position range half-width .02m -> .005m maximum per policy step.
        self.gripper_command+=np.array([-1,1])*.005*np.sign(action[-1])
        self.gripper_command=np.clip(self.gripper_command,[0,-.04],[.04,0])
        self.world.control_dofs_position(self.gripper_command,self.gripper_idx)
        for _ in range(5):
            self.scene.step()


def build_vla_scene(control='osc',fleet=False):
    import genesis as gs
    if not getattr(gs,'_initialized',False):
        gs.init(backend=gs.cuda,precision='32',logging_level='warning',seed=17)
    reference=json.loads((ROOT/'output/vla/native_scene_manifest.json').read_text())
    scene=gs.Scene(sim_options=gs.options.SimOptions(dt=.002 if control=='osc' else .01,substeps=1 if control=='osc' else 5),
        rigid_options=gs.options.RigidOptions(enable_self_collision=True,enable_torsional_friction=True,enable_mujoco_compatibility=True,
            friction_cone=gs.friction_cone.elliptic,impratio=20),
        vis_options=gs.options.VisOptions(ambient_light=(.6,.6,.6),show_world_frame=False),show_viewer=False)
    print('Loading public task MJCF into Genesis...',flush=True)
    # MJCF preserves its fixed links; URDF-only links_to_keep is not an MJCF option.
    model_file=prepare_genesis_xml(ROOT/'output/vla/libero_scene.xml',ROOT/'output/vla/genesis_scene.xml')
    cargo_ref=next(j for j in reference['joint_qpos'] if j['name']=='akita_black_bowl_1_joint0')
    dock_xy=np.asarray(cargo_ref['qpos'][:2])
    if fleet:
        from .fleet import cut_lift_port
        cut_lift_port(model_file,dock_xy)
    world=scene.add_entity(gs.morphs.MJCF(file=str(model_file),align=False,
        decimate=True,convexify=True,decompose_robot_error_threshold=float('inf')))
    amrs=[]
    overview=None
    if fleet:
        for _ in range(2):amrs.append(scene.add_entity(gs.morphs.MJCF(file=str(ROOT/'assets/amr_lift.xml'),align=False)))
        overview=scene.add_camera(res=(960,600),pos=(2.5,-2.8,2.9),lookat=(-.45,0,.55),fov=62,near=.01,GUI=False)
    cameras=[]
    for name in ['agentview','robot0_eye_in_hand']:
        cam=reference['cameras'][name]
        c=scene.add_camera(res=(256,256),pos=cam['pos'],lookat=np.asarray(cam['pos'])-np.asarray(cam['rotation'])[:,2],
            up=np.asarray(cam['rotation'])[:,1],fov=cam['fovy'],near=reference.get('camera_near',.010609816),GUI=False)
        cameras.append(c)
    print('Building public task physics in Genesis...',flush=True)
    scene.build()
    q=numpy(world.get_qpos()).copy()
    for joint in reference['joint_qpos']:
        indices=world.get_joint(joint['name']).qs_idx_local
        q[indices]=joint['qpos']
    world.set_qpos(q)
    ee=world.get_link('gripper0_eef')
    arm_idx=[world.get_joint(f'robot0_joint{i}').dofs_idx_local[0] for i in range(1,8)]
    gripper_idx=[world.get_joint(f'gripper0_finger_joint{i}').dofs_idx_local[0] for i in range(1,3)]
    world.set_dofs_kp(np.array([4500,4500,3500,3500,2000,2000,2000]),arm_idx)
    world.set_dofs_kv(np.array([450,450,350,350,200,200,200]),arm_idx)
    world.set_dofs_kp(np.array([1000,1000]),gripper_idx)
    world.set_dofs_kv(np.array([0,0]) if control=='osc' else np.array([80,80]),gripper_idx)
    world.set_dofs_force_range(np.array([-80,-80,-80,-80,-80,-12,-12]),np.array([80,80,80,80,80,12,12]),arm_idx)
    world.set_dofs_force_range(np.array([-20,-20]),np.array([20,20]),gripper_idx)
    camera=reference['cameras']['robot0_eye_in_hand']
    tcamera=np.eye(4);tcamera[:3,:3]=camera['rotation'];tcamera[:3,3]=camera['pos']
    offset=np.linalg.inv(transform(numpy(ee.get_pos()),numpy(ee.get_quat())))@tcamera
    cameras[1].attach(ee,offset)
    f=VLAScene(scene,world,cameras[0],cameras[1],ee,arm_idx,gripper_idx,reference)
    if fleet:
        for i,amr in enumerate(amrs):
            amr.set_dofs_kp(np.array([1800,1800,900,2200]))
            amr.set_dofs_kv(np.array([180,180,80,100]))
            amr.set_dofs_force_range(np.array([-400,-400,-150,-200]),np.array([400,400,150,200]))
            start=np.array([.4,1.5 if i==0 else -1.5,0,0])
            amr.set_dofs_position(start);amr.control_dofs_position(start)
        # Physical cargo starts on the first vehicle's low platform, not at the workcell.
        q=numpy(world.get_qpos()).copy()
        indices=world.get_joint(cargo_ref['name']).qs_idx_local
        cargo=np.asarray(cargo_ref['qpos']).copy();cargo[:3]=[-1.6,1.5,cargo[2]-.5]
        q[indices]=cargo;world.set_qpos(q)
        f.amrs=amrs;f.overview=overview;f.dock_xy=dock_xy
    if control=='osc':
        from .osc import ModelOSC
        f.osc=ModelOSC(ROOT/'output/vla/libero_scene.xml',reference)
    f.hold()
    print('Genesis VLA cell ready; eef=',f.state()[:3],flush=True)
    return f
