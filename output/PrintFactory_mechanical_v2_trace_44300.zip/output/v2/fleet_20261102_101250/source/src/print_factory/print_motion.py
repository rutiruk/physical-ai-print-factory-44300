"""Conventional actuators for finished-book stack transfer; paper receives no pose commands."""
import numpy as np
from .scene import numpy


def finish_transfer(f,step):
    trace=[]
    # The receiving bridge belongs to pile replenishment; retract it before the bound lot leaves.
    f.gather_bridge.control_dofs_position(np.array([0.]));step(100)
    def move(target,speed=.4):
        start=numpy(f.loader.get_dofs_position()).copy();target=np.asarray(target,float)
        duration=max(np.linalg.norm(target[:3]-start[:3])/speed,abs(target[3]-start[3])/.8,.3)
        steps=max(1,int(duration/.01))
        for i in range(steps):
            a=(i+1)/steps;s=a*a*(3-2*a)
            f.loader.control_dofs_position(start+(target-start)*s);step(1)
            if i%25==0:trace.append(numpy(f.book_block.get_pos()).tolist())
        step(25)
    current=numpy(f.loader.get_dofs_position()).copy();current[2]=.8;move(current)
    move([1.8725,1.25,.8,np.pi/2])
    move([1.8725,1.25,.415,np.pi/2])
    move([3.0725,1.25,.415,np.pi/2],speed=.25)
    move([3.0725,1.25,.8,np.pi/2])
    trace.append(numpy(f.book_block.get_pos()).tolist())
    return trace
