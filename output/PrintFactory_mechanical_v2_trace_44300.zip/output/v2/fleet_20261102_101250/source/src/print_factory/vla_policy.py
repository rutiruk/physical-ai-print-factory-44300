"""Real, pretrained SmolVLA inference. This module never substitutes an expert trajectory."""
import hashlib
from pathlib import Path
import time
import numpy as np

MODEL_ID = 'lerobot/smolvla_libero'
REVISION = 'a24f1f380461b665158d52acd140152c79e8b36d'


def validate_action(action):
    if action is None:
        raise ValueError('VLA action unavailable; holding position, no fallback controller')
    action = np.asarray(action, dtype=np.float32)
    if action.shape != (7,) or not np.isfinite(action).all():
        raise ValueError(f'Invalid VLA action: shape={action.shape}; expected finite 7D action')
    return action


def make_state(eef_xyz, eef_quat_xyzw, gripper_qpos):
    # Match LeRobot LiberoProcessorStep exactly, including the sign convention.
    q = np.asarray(eef_quat_xyzw, dtype=float)
    w = np.clip(q[3], -1, 1)
    den = np.sqrt(max(1-w*w, 0))
    rotation = q[:3] * (2*np.arccos(w)/den) if den > 1e-10 else np.zeros(3)
    return np.r_[eef_xyz, rotation, gripper_qpos].astype(np.float32)


class SmolPolicy:
    def __init__(self, model_dir='output/vla/models/smolvla-libero', device=None):
        import os
        os.environ['USE_TF'] = '0'
        os.environ['USE_FLAX'] = '0'
        import torch
        from lerobot.policies.smolvla.modeling_smolvla import SmolVLAPolicy
        from lerobot.configs.policies import PreTrainedConfig
        from lerobot.policies.factory import make_pre_post_processors
        device = device or ('cuda:1' if torch.cuda.device_count() > 1 else 'cuda:0')
        self.torch, self.device = torch, device
        torch.set_num_threads(4)
        self.model_dir = Path(model_dir)
        config = PreTrainedConfig.from_pretrained(self.model_dir)
        config.device = device
        # All policy weights are loaded STRICTLY from the task-trained checkpoint below.
        # Avoid downloading/loading redundant VLM weights that would immediately be overwritten.
        config.load_vlm_weights = False
        config.n_action_steps = 5
        print(f'Loading real pretrained VLA: {MODEL_ID}@{REVISION}', flush=True)
        self.policy = SmolVLAPolicy.from_pretrained(self.model_dir, config=config, strict=True).eval()
        self.preprocess, self.postprocess = make_pre_post_processors(config, self.model_dir,
            preprocessor_overrides={'device_processor': {'device': device}})
        self.calls = 0
        self.latencies_ms = []

    def reset(self):
        self.policy.reset()

    def predict(self, image, wrist_image, state, instruction):
        torch = self.torch
        batch = {'observation.images.image': torch.from_numpy(np.ascontiguousarray(image.transpose(2, 0, 1))).float()/255,
                 'observation.images.image2': torch.from_numpy(np.ascontiguousarray(wrist_image.transpose(2, 0, 1))).float()/255,
                 'observation.state': torch.as_tensor(state, dtype=torch.float32), 'task': instruction}
        batch = self.preprocess(batch)
        torch.cuda.synchronize(self.device)
        start = time.perf_counter()
        with torch.inference_mode():
            action = self.postprocess(self.policy.select_action(batch))
        torch.cuda.synchronize(self.device)
        self.latencies_ms.append((time.perf_counter()-start)*1000)
        self.calls += 1
        return validate_action(action.detach().cpu().numpy().reshape(-1))

    def manifest(self):
        return {'model_id': MODEL_ID, 'revision': REVISION, 'policy_class': type(self.policy).__name__,
                'weight_sha256': hashlib.sha256((self.model_dir/'model.safetensors').read_bytes()).hexdigest(),
                'device': self.device, 'strict_weights_loaded': True, 'additional_training': False,
                'action_shape': [7], 'state_shape': [8], 'n_action_steps': 5,
                'inference_calls': self.calls, 'latencies_ms': self.latencies_ms}
