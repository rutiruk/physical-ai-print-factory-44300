"""Generate labeled Genesis camera images, fit a tiny RGB-only CNN, evaluate held-out scenes."""
import json
from pathlib import Path
import time
import numpy as np
import torch
from torch import nn
from .scene import build_scene
from .vision import PixelNet, Calibration, detection, semantic_labels


def collect(count=96):
    f = build_scene()
    images, labels, positions = [], [], []
    for i in range(count):
        # Disjoint scene seeds; the last quarter is never used in fitting.
        rng = np.random.default_rng(i + 1000)
        xy = rng.uniform([-2.2, -1.25], [1.4, 1.25])
        f.amr.set_dofs_position(np.r_[xy + [2, 0], 0])
        f.amr.control_dofs_position(np.r_[xy + [2, 0], 0])
        bundle_xy = xy + rng.uniform(-0.03, 0.03, 2)
        f.bundle.set_pos((*bundle_xy, 0.45))
        f.obstacle.set_pos((rng.uniform(-0.6, 0.6), rng.uniform(-1.15, 1.15), 0.30))
        f.scene.step()
        rgb, _, seg, _ = f.overhead.render(segmentation=True)
        seg = np.asarray(seg).squeeze()
        label = semantic_labels(seg, f.scene.segmentation_idx_dict,
                                {f.bundle.idx: 1, f.amr.idx: 2, f.obstacle.idx: 3})
        images.append(rgb)
        labels.append(label)
        positions.append(bundle_xy)
        if i % 16 == 0:
            print(f'camera dataset {i}/{count}', flush=True)
    return np.array(images), np.array(labels), np.array(positions)


def train(out='output', count=96, iterations=600):
    out = Path(out)
    out.mkdir(exist_ok=True)
    torch.manual_seed(123)
    torch.set_num_threads(4)
    dataset = out / 'dataset.npz'
    if dataset.exists():
        data = np.load(dataset)
        images, labels, positions = data['images'], data['labels'], data['positions']
    else:
        images, labels, positions = collect(count)
        np.savez_compressed(dataset, images=images, labels=labels, positions=positions)
    split = len(images) * 3 // 4
    pixels = images[:split].reshape(-1, 3)
    targets = labels[:split].reshape(-1)
    rng = np.random.default_rng(123)
    indices = [np.where(targets == cls)[0] for cls in range(4)]
    if any(len(index) == 0 for index in indices):
        raise RuntimeError(f'Missing semantic classes: {[len(x) for x in indices]}; inspect renderer segmentation IDs')
    model = PixelNet().cuda()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.008)
    for step in range(iterations):
        ix = np.concatenate([rng.choice(index, 1024) for index in indices])
        color = pixels[ix].astype(np.float32) / 255
        # Photometric augmentation only during training.
        color = np.clip(color * rng.uniform(0.72, 1.22, (len(ix), 1)) + rng.normal(0, 0.014, color.shape), 0, 1)
        x = torch.tensor(color.T[None, :, None], dtype=torch.float32, device='cuda')
        y = torch.tensor(targets[ix][None, None], dtype=torch.long, device='cuda')
        loss = nn.functional.cross_entropy(model(x), y)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        if step % 150 == 0:
            print(f'CNN step {step}: loss={loss.item():.4f}', flush=True)
    torch.save({'state_dict': model.cpu().state_dict()}, out / 'vision.pt')
    model.cuda().eval()
    intersection = np.zeros(4)
    union = np.zeros(4)
    errors, latency = [], []
    cal = Calibration()
    with torch.inference_mode():
        for rgb, truth, xy in zip(images[split:], labels[split:], positions[split:]):
            x = torch.tensor(rgb.transpose(2, 0, 1).copy(), dtype=torch.float32, device='cuda')[None] / 255
            torch.cuda.synchronize()
            start = time.perf_counter()
            prob = model(x).softmax(1)
            confidence, pred = prob.max(1)
            pred[confidence < .7] = 0
            torch.cuda.synchronize()
            latency.append((time.perf_counter() - start) * 1000)
            pred = pred[0].cpu().numpy()
            for cls in range(4):
                intersection[cls] += ((pred == cls) & (truth == cls)).sum()
                union[cls] += ((pred == cls) | (truth == cls)).sum()
            center = detection(pred, 1)
            if center is not None:
                errors.append(float(np.linalg.norm(cal.image_to_world(center, .52) - xy)))
    metrics = dict(train_seeds=list(range(1000, 1000 + split)), heldout_seeds=list(range(1000 + split, 1000 + len(images))),
                   class_iou=(intersection / np.maximum(union, 1)).tolist(),
                   bundle_position_error_mean_m=float(np.mean(errors)) if errors else None,
                   detected_heldout=len(errors), heldout_count=len(images)-split,
                   inference_mean_ms=float(np.mean(latency)), class_train_pixels=[len(x) for x in indices],
                   model='RGB 1x1 CNN (3-24-24-4), synthetic color-coded factory domain')
    (out / 'vision_metrics.json').write_text(json.dumps(metrics, indent=2))
    print(json.dumps(metrics, indent=2), flush=True)
    return metrics
