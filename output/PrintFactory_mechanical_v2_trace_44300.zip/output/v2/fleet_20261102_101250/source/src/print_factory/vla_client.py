"""Process boundary: only observations in and actual model actions out."""
import base64
import json
from pathlib import Path
from queue import Queue, Empty
from threading import Thread
import subprocess
import numpy as np
from .vla_policy import validate_action

ROOT=Path(__file__).resolve().parents[2]


class VLAClient:
    def __init__(self,worker='vla_worker.py',log_path='output/vla/worker.log'):
        self.process=subprocess.Popen([str(ROOT/'.venv-policy/Scripts/python.exe'),'-u',str(ROOT/'scripts'/worker)],
            cwd=str(ROOT),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
            text=True,encoding='utf-8',errors='replace',bufsize=1)
        self.queue=Queue()
        self.log=(ROOT/log_path).open('w',encoding='utf-8')
        def read():
            for line in self.process.stdout:
                self.log.write(line);self.log.flush()
                if line.startswith('VLA_RESULT '):self.queue.put(json.loads(line[len('VLA_RESULT '):]))
            self.queue.put({'status':'error','error':'VLA worker exited'})
        self.reader=Thread(target=read,daemon=True);self.reader.start()
        self.ready=self.receive()
        if self.ready['status']!='ready':raise RuntimeError(self.ready)

    def receive(self):
        try:result=self.queue.get(timeout=180)
        except Empty:raise RuntimeError('VLA timeout; stopping without fallback')
        if result['status']=='error':raise RuntimeError(result['error'])
        return result

    def request(self,payload):
        self.process.stdin.write(json.dumps(payload)+'\n');self.process.stdin.flush()
        return self.receive()

    def predict(self,image,wrist,state,instruction):
        payload={'type':'predict','image':base64.b64encode(np.ascontiguousarray(image).tobytes()).decode(),
                 'wrist':base64.b64encode(np.ascontiguousarray(wrist).tobytes()).decode(),
                 'state':np.asarray(state).tolist(),'instruction':instruction}
        return validate_action(self.request(payload)['action'])

    def manifest(self):return self.request({'type':'manifest'})['model']

    def predict_joints(self,joints,state,instruction):
        result=self.request({'type':'predict_joints','joints':joints,'state':np.asarray(state).tolist(),'instruction':instruction})
        images=[np.frombuffer(base64.b64decode(result[key]),np.uint8).reshape(256,256,3) for key in ('image','wrist')]
        return validate_action(result['action']),images

    def close(self):
        if self.process.poll() is None:
            self.process.stdin.write('{"type":"quit"}\n');self.process.stdin.flush()
            self.process.wait(timeout=30)
        self.reader.join(timeout=5)
        if not self.reader.is_alive():self.log.close()
