"""Failure-inclusive evaluation, with checkpointing after every attempted episode."""
import json
from pathlib import Path


def evaluate(out='output', build=None, episode=None):
    if build is None:
        from .scene import build_scene
        build = build_scene
    if episode is None:
        from .run import run_episode
        episode = run_episode
    out = Path(out)
    out.mkdir(exist_ok=True)
    factory = None
    results = []
    for obstacle in (False, True):
        for seed in range(2000, 2005):
            try:
                if factory is None:
                    factory = build()
                result = episode(seed=seed, obstacle=obstacle, factory=factory)
            except Exception as error:
                result = dict(seed=seed, obstacle=obstacle, completed=False, duration_s=None,
                              obstacle_contact_steps=None, replans=None,
                              error=f'{type(error).__name__}: {error}')
                # A partially failed simulation may be unusable; never silently reuse it.
                factory = None
                print(f'Evaluation failed: {result}', flush=True)
            results.append(result)
            (out / 'evaluation.json').write_text(json.dumps(results, indent=2))
    summary = {}
    for obstacle in (False, True):
        rows = [r for r in results if r['obstacle'] == obstacle]
        durations = [r['duration_s'] for r in rows if r['duration_s'] is not None]
        summary['obstacle' if obstacle else 'normal'] = {
            'trials': len(rows), 'completed': sum(r['completed'] for r in rows),
            'errors': sum('error' in r for r in rows),
            'obstacle_contact_steps': sum(r['obstacle_contact_steps'] or 0 for r in rows),
            'contact_metrics_available_trials': sum(r['obstacle_contact_steps'] is not None for r in rows),
            'mean_duration_s': sum(durations) / len(durations) if durations else None,
        }
    (out / 'evaluation_summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2), flush=True)
    return results, summary
