"""Public robotics foundation model as a factory decision policy, not a motor VLA."""
import json,re,time,hashlib
from pathlib import Path

MODEL_ID='BAAI/RoboBrain2.5-4B'
REVISION='ec4b3bf5e969b48ad17df432b479c10402a0079b'


def route_blocked(route,sx,dx,obstacle_xy):
    """Independent perfect clearance interlock; it vetoes but never replaces model choices."""
    ox,oy=obstacle_xy
    path=[(sx,.55),(dx,.55)] if route=='direct' else [(sx,.55),(sx,-.65),(dx,-.65),(dx,.55)]
    for (ax,ay),(bx,by) in zip(path,path[1:]):
        if min(ax,bx)-.575<ox<max(ax,bx)+.575 and min(ay,by)-.515<oy<max(ay,by)+.515:
            return True
    return False


def route_view(rgb,sx,dx):
    """Project known candidate paths, not obstacle truth, onto the real ceiling RGB."""
    from PIL import Image,ImageDraw,ImageFont
    import math
    raw=Image.fromarray(rgb[:512,:768]).copy()
    canvas=Image.new('RGB',(768,736),'#101923');canvas.paste(raw,(0,0));draw=ImageDraw.Draw(canvas)
    scale=2*7*math.tan(math.radians(31))/512
    def pixel(x,y):return (x/scale+384,256-y/scale)
    direct=[pixel(sx,.55),pixel(dx,.55)]
    south=[pixel(sx,.55),pixel(sx,-.65),pixel(dx,-.65),pixel(dx,.55)]
    draw.line(direct,fill='#28bcff',width=3);draw.line(south,fill='#ffe02b',width=3)
    font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',16)
    draw.text(pixel((sx+dx)/2,.95),'A DIRECT',font=font,fill='#28bcff',stroke_width=1,stroke_fill='black')
    draw.text(pixel((sx+dx)/2,-1.05),'B SOUTH',font=font,fill='#ffe02b',stroke_width=1,stroke_fill='black')
    # Camera pixels in each vehicle swept corridor. The mask depends only on candidate paths,
    # camera calibration and vehicle size; no object IDs/positions are used to create it.
    for i,path in enumerate([direct,south]):
        mask=Image.new('L',raw.size,0);md=ImageDraw.Draw(mask)
        md.line(path,fill=255,width=42)
        for p in path:md.ellipse((p[0]-21,p[1]-21,p[0]+21,p[1]+21),fill=255)
        crop=Image.composite(raw,Image.new('RGB',raw.size,'#101923'),mask)
        bounds=mask.getbbox();crop=crop.crop(bounds);crop.thumbnail((360,174))
        canvas.paste(crop,(i*384+12,550))
        draw.text((i*384+12,520),['A DIRECT corridor','B SOUTH corridor'][i],font=font,fill='white')
    return canvas


def parse_decision(text,eligible):
    match=re.search(r'\{[^{}]*\}',text)
    if not match:raise ValueError('Model did not return an executable decision')
    result=json.loads(match.group())
    if result.get('task') not in eligible or result.get('amr') not in (1,2) or result.get('route') not in ('direct','south'):
        raise ValueError('Model decision violates task/robot/route contract')
    return result


class FactoryBrain:
    def __init__(self,device='cuda:1'):
        import torch
        from transformers import AutoModelForImageTextToText,AutoProcessor
        self.torch=torch;self.device=device;torch.set_num_threads(4)
        path=Path(__file__).resolve().parents[2]/'output/printing/models/robobrain'
        self.model,loading=AutoModelForImageTextToText.from_pretrained(path,dtype=torch.bfloat16,
             device_map=device,attn_implementation='sdpa',local_files_only=True,output_loading_info=True)
        if any(loading.get(k) for k in ('missing_keys','unexpected_keys','mismatched_keys','error_msgs')):
            raise RuntimeError(f'Incomplete foundation model load: {loading}')
        self.model.eval()
        self.processor=AutoProcessor.from_pretrained(path,local_files_only=True)
        digest=hashlib.sha256()
        with (path/'model.safetensors').open('rb') as weights:
            for chunk in iter(lambda:weights.read(8*1024*1024),b''):digest.update(chunk)
        self.weight_sha256=digest.hexdigest()
        self.calls=[]

    def decide(self,image,eligible,plc):
        spatial_prompt=('Inspect the TWO BOTTOM corridor camera panels labeled A DIRECT corridor and B SOUTH corridor. '
                        'Each shows only the actual camera pixels inside that candidate vehicle swept path. '
                        'Does panel A contain a bright RED crate? Does panel B contain a bright RED crate? '
                        'State which panel contains red and which route is clear. If neither contains red, both routes are clear. '
                        'Ignore the overall diagram for this question; compare the bottom panels.')
        visual,visual_elapsed=self.query(image,spatial_prompt)
        prompt=('You coordinate a sheetfed UV printing factory making16-page saddle-stitched brochures. '
                'The actual ceiling camera image shows the workshop. White piles are paper, cyan vehicles are AMRs, '
                'the large red crate is an obstacle. Station order is PRESS at left, FOLDER in middle, GATHER at right. '
                'Two exact candidate trajectories are overlaid: cyan A DIRECT and yellow B SOUTH. '
                'A route is BLOCKED if its colored line intersects the visible red crate. '
                'Inspect both lines in the image. The south route detours through the open lower part. '
                'Choose an eligible transfer, an idle AMR, and a collision-free route based on the image. '
                'For AMR assignment, prefer an available vehicle whose reported position is closer to the source port. '
                'Select south if cyan A intersects red; otherwise select direct for the shorter clear route. '
                'Do not invent print quality from pixels. '
                'Your preceding visual assessment: '+visual+'. '
                'PLC/barcode observations: '+json.dumps(plc)+'. Eligible task IDs: '+json.dumps(eligible)+'. '
                'First identify which colored path intersects the red obstacle in one short sentence. '
                'Then finish with JSON with keys task, amr (1 or2), route (direct or south).')
        # Planning consumes the model's own visual assessment plus PLC; do not reinterpret
        # the full overview a second time and silently contradict the corridor assessment.
        answer,elapsed=self.query(None,prompt)
        record={'eligible':eligible,'plc':plc,'raw_output':answer,'decision':None,
                           'visual_assessment':visual,'visual_wall_s':visual_elapsed,
                           'image_sha256':hashlib.sha256(image.tobytes()).hexdigest(),
                           'wall_s':elapsed}
        self.calls.append(record)
        decision=parse_decision(answer,eligible);record['decision']=decision
        return decision

    def query(self,image,prompt):
        content=([{'type':'image','image':image}] if image is not None else [])+[{'type':'text','text':prompt}]
        messages=[{'role':'user','content':content}]
        text=self.processor.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
        inputs=self.processor(text=[text],images=[image] if image is not None else None,return_tensors='pt').to(self.device)
        start=time.perf_counter()
        with self.torch.inference_mode():
            result=self.model.generate(**inputs,max_new_tokens=384,do_sample=False)
        answer=self.processor.decode(result[0,inputs.input_ids.shape[1]:],skip_special_tokens=True)
        return answer,time.perf_counter()-start

    def manifest(self):
        return {'model_id':MODEL_ID,'revision':REVISION,'role':'robotics embodied VLM planning, not low-level motor VLA',
                'additional_training':False,'device':self.device,'weight_sha256':self.weight_sha256,
                'strict_weights_loaded':True,'parameters':sum(p.numel() for p in self.model.parameters()),
                'peak_vram_bytes':self.torch.cuda.max_memory_allocated(self.device),'calls':self.calls}
