import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description='PrintFactory AI / Genesis CUDA')
    parser.add_argument('command', choices=['smoke', 'train', 'demo', 'evaluate'])
    parser.add_argument('--seed', type=int, default=2000)
    parser.add_argument('--normal', action='store_true')
    parser.add_argument('--count', type=int, default=96)
    parser.add_argument('--iterations', type=int, default=600)
    args = parser.parse_args()
    if args.command == 'smoke':
        import runpy
        runpy.run_path(str(Path(__file__).resolve().parents[2] / 'scripts/smoke.py'), run_name='__main__')
    elif args.command == 'train':
        from .train import train
        train(count=args.count, iterations=args.iterations)
    else:
        from .run import run_episode
        if args.command == 'demo':
            run_episode(seed=args.seed, obstacle=not args.normal, record=True)
        else:
            from .evaluation import evaluate
            evaluate()


if __name__ == '__main__':
    main()
