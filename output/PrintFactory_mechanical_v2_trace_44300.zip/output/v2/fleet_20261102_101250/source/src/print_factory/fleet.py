"""Conventional shared-resource arbitration. This is intentionally not called AI."""
from collections import deque
import xml.etree.ElementTree as ET


def cut_lift_port(path,center,halfwidth=.066):
    """Four solid table strips around a small physical elevator aperture."""
    tree=ET.parse(path)
    x,y=center;h=halfwidth
    strips=[(-.5,x-h,-.6,.6),(x+h,.5,-.6,.6),(x-h,x+h,-.6,y-h),(x-h,x+h,y+h,.6)]
    for body in tree.findall('.//body'):
        for geom in list(body.findall('geom')):
            if geom.get('name') not in ('table_collision','table_visual'):continue
            body.remove(geom)
            for i,(a,b,c,d) in enumerate(strips):
                attributes=dict(geom.attrib)
                attributes.update(name=geom.get('name')+str(i),pos=f'{(a+b)/2} {(c+d)/2} 0',size=f'{(b-a)/2} {(d-c)/2} .025')
                ET.SubElement(body,'geom',attributes)
    tree.write(path,encoding='unicode')


class DockReservation:
    def __init__(self):
        self.owner = None
        self.waiting = deque()

    def request(self, robot_id):
        if self.owner is None:
            self.owner = robot_id
        if self.owner == robot_id:
            return True
        if robot_id not in self.waiting:
            self.waiting.append(robot_id)
        return False

    def release(self, robot_id):
        if robot_id != self.owner:
            raise ValueError('Only the dock owner can release the physical shared resource')
        self.owner = self.waiting.popleft() if self.waiting else None

    def require_owner(self,robot_id):
        if self.owner!=robot_id:raise PermissionError('Robot must own dock before entering')
