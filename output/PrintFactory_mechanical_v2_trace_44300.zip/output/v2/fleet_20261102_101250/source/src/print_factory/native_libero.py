"""Load published benchmark initial states, without collecting or training on new data."""
from pathlib import Path
import os
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'vendor/LIBERO/libero/libero'


def make_native(task_id=0,init_id=0):
    import yaml
    config=ROOT/'output/vla/libero_config'
    config.mkdir(parents=True,exist_ok=True)
    os.environ['LIBERO_CONFIG_PATH']=str(config)
    os.environ['MUJOCO_GL']='glfw'
    sys.path.insert(0,str(ROOT/'vendor/LIBERO'))
    paths={'benchmark_root':str(BASE),'bddl_files':str(BASE/'bddl_files'),'init_states':str(BASE/'init_files'),
           'datasets':str(BASE/'../datasets'),'assets':str(BASE/'assets')}
    (config/'config.yaml').write_text(yaml.safe_dump(paths))
    from libero.libero import benchmark
    from libero.libero.envs import OffScreenRenderEnv
    import torch
    suite=benchmark.get_benchmark_dict()['libero_spatial']()
    task=suite.get_task(task_id)
    env=OffScreenRenderEnv(bddl_file_name=str(BASE/'bddl_files'/task.problem_folder/task.bddl_file),
                          camera_heights=256,camera_widths=256)
    env.seed(0)
    env.reset()
    # Trusted initial-state file from the pinned official LIBERO repository, not an uploaded pickle.
    states=torch.load(BASE/'init_files'/task.problem_folder/task.init_states_file,weights_only=False,map_location='cpu')
    obs=env.set_init_state(states[init_id])
    for _ in range(10):obs,_,_,_=env.step(np.array([0,0,0,0,0,0,-1]))
    return env,obs,task,suite


def render_observation(env,joints):
    """Render a supplied pose only; never advance MuJoCo physics or generate teacher actions."""
    for name,values in joints.items():
        address=env.sim.model.get_joint_qpos_addr(name)
        if isinstance(address,tuple):env.sim.data.qpos[address[0]:address[1]]=values
        else:env.sim.data.qpos[address]=values[0]
    env.sim.forward()
    env.env._update_observables(force=True)
    return env.env._get_observations(force_update=True)
