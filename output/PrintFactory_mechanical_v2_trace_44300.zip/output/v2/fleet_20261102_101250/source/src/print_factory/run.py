"""Closed-loop episode. Truth is used for reset and scoring, never target detection."""
import json
from pathlib import Path
import time
import numpy as np
import imageio.v2 as imageio
from .scene import build_scene, numpy
from .vision import Perception, Calibration, detection
from .planning import astar, inflate, grasp_allowed, facility_map, update_obstacles
from .video import compose, VideoWriter

STATES = {
    'PRINT': ('01 印刷完了を待つ', '印刷機の完了信号と、天井画像で検出した紙束を確認。'),
    'DRIVE': ('02 目と足が協調して搬送', 'AIの観測から走行経路を作成。AMRが紙束を運びます。'),
    'REPLAN': ('03 通路変化を認識 → 再計画', '追加された障害物をRGB画像から検出。停止して迂回路を選びます。'),
    'APPROACH': ('04 目と手が協調して位置合わせ', 'カメラから推定した紙束の位置へ、吸着ハンドを動かします。'),
    'LIFT': ('05 吸着して持ち上げる', '近接を確認して吸着を開始。紙束は物理的な固定拘束で保持します。'),
    'PLACE': ('06 後工程のトレイへ投入', '直交型ロボットが搬送。トレイ直上で吸着を解除します。'),
    'FINISH': ('07 後工程を実行', '紙束の到着を確認。断裁・製本の内部処理は時間付き状態遷移で近似。'),
    'DONE': ('完了：工場全体で一つのタスクを実行', '天井カメラが目、AMRが足、固定ロボットが手。形状を越えて協調します。'),
    'WAIT': ('認識待ち：停止', '対象が見つからないか、経路がありません。観測を更新して待機します。'),
}


def guard_commands(amr_command, arm_command, actual_amr, actual_arm, valid, age):
    if not valid or not 0 <= age <= .6:
        return np.array(actual_amr, copy=True), np.array(actual_arm, copy=True)
    return amr_command, arm_command


def run_episode(seed=2000, obstacle=True, record=False, out='output', factory=None):
    f = factory or build_scene()
    out = Path(out)
    out.mkdir(exist_ok=True)
    rng = np.random.default_rng(seed)
    f.scene.reset()
    f.hold()
    # Only initialization knows ground-truth poses. The control loop does not read them.
    start_y = float(rng.uniform(-.08, .08))
    f.amr.set_dofs_position(np.array([0, start_y, 0]))
    f.amr.control_dofs_position(np.array([0, start_y, 0]))
    f.bundle.set_pos((-2, start_y, .58))
    f.obstacle.set_pos((0, 0, -2))
    obstacle_y = float(rng.uniform(-.10, .10))
    perception, cal = Perception(out / 'vision.pt'), Calibration()
    route, blocked = [], np.zeros((256, 256), bool)
    rgb = np.zeros((256, 256, 3), np.uint8)
    mask = np.zeros((256, 256), np.uint8)
    writer = VideoWriter(out / 'print_factory_demo.mp4', 12.5) if record else None
    state, since = 'PRINT', 0.
    goal = np.array([1.45, start_y])
    inserted, obstacle_seen = False, False
    replans, contact_steps, frames = 0, 0, 0
    first_plan = True
    last_detection, target_xy, pick_target = -10., None, None
    current_bundle_valid = False
    obstacle_memory = np.zeros((256, 256), bool)
    events, trajectory = [], []
    last_arm_command = np.array([0., 0., 0.])
    amr_command = np.array([0., start_y, 0.])
    completed, release_time, completed_at = False, None, None
    runtime_start = time.perf_counter()
    tool = f.arm.get_link('tool')
    link_bundle = f.bundle.links[0].idx
    weld_active = False

    def change(next_state, t):
        nonlocal state, since
        events.append({'time_s': round(t, 2), 'state': next_state})
        print(f'seed {seed}: {t:.2f}s {state} -> {next_state}', flush=True)
        state, since = next_state, t

    def plan(xy):
        nonlocal route, replans, first_plan
        start = cal.world_to_pixel(xy, .395)[::-1].round().astype(int)
        end = cal.world_to_pixel(goal, .395)[::-1].round().astype(int)
        route = astar(blocked, tuple(start), tuple(end))
        if not first_plan:
            replans += 1
        first_plan = False

    try:
        for step in range(5000):
            t = step * .02
            xy = f.amr_position()[:2]
            # Scenario injection, separate from the controller's observation.
            if obstacle and not inserted and xy[0] > -1.15:
                f.obstacle.set_pos((0, obstacle_y, .30))
                inserted = True
                events.append({'time_s': round(t, 2), 'state': 'SCENARIO_OBSTACLE_ADDED'})
            if step % 10 == 0:
                rgb = f.overhead.render()[0]
                mask = perception.predict(rgb)
                center = detection(mask, 1)
                current_bundle_valid = center is not None
                if center is not None:
                    target_xy = cal.image_to_world(center, .535)
                    last_detection = t
                obstacle_mask = mask == 3
                current_seen = int(obstacle_mask.sum()) >= 12
                obstacle_memory = update_obstacles(obstacle_memory, mask)
                # Scenario obstacles are stationary once introduced. Do not erase them on a missed frame.
                blocked = inflate(obstacle_memory, 17) | facility_map(cal)
                if state == 'DRIVE' and current_seen and not obstacle_seen:
                    obstacle_seen = True
                    amr_command = np.r_[xy + [2, 0], 0]
                    route = []
                    change('REPLAN', t)
                if state == 'DRIVE' and (not route or any(blocked[p] for p in route)):
                    plan(xy)

            if state == 'PRINT' and t >= 4 and current_bundle_valid and t - last_detection <= .6:
                # A recognized bundle on the deck triggers the print-complete handoff.
                change('DRIVE', t)
                plan(xy)
            elif state == 'REPLAN':
                if t - since >= 2:
                    plan(xy)
                    if route:
                        change('DRIVE', t)
            elif state == 'DRIVE':
                if not current_bundle_valid or t - last_detection > .6:
                    amr_command = np.r_[xy + [2, 0], 0]
                elif np.linalg.norm(xy - goal) < .04:
                    amr_command = np.r_[goal + [2, 0], 0]
                    change('APPROACH', t)
                elif route:
                    world = np.array([cal.image_to_world((c, r), .395) for r, c in route])
                    nearest = int(np.argmin(np.linalg.norm(world - xy, axis=1)))
                    index = min(nearest + 4, len(world) - 1)
                    delta = world[index] - xy
                    dist = np.linalg.norm(delta)
                    speed = .15
                    # PD steady velocity = kp*offset/(kv+joint damping).
                    offset = speed * (180 + 8) / 1800
                    next_xy = xy + delta / max(dist, 1e-8) * min(dist, offset)
                    # Moving position targets make the PD controller the actual actuator.
                    amr_command = np.r_[next_xy + [2, 0], 0]
            elif state == 'APPROACH':
                if current_bundle_valid and target_xy is not None and t - last_detection <= .6:
                    pick_target = np.r_[target_xy, .56]
                    desired = pick_target if t - since > 3 else np.r_[target_xy, .90]
                    q = desired - [2, 0, 1.4]
                    last_arm_command += np.clip(q - last_arm_command, -.003, .003)
                    if t - since > 6 and grasp_allowed(numpy(tool.get_pos()), pick_target, t - last_detection):
                        f.scene.sim.rigid_solver.add_weld_constraint(link_bundle, tool.idx)
                        weld_active = True
                        events.append({'time_s': round(t, 2), 'state': 'GRASP', 'target_source': 'CNN_RGB', 'target_xyz': pick_target.tolist(), 'tool_xyz': numpy(tool.get_pos()).tolist()})
                        change('LIFT', t)
            elif state == 'LIFT':
                q = np.r_[pick_target[:2], 1.1] - [2, 0, 1.4]
                last_arm_command += np.clip(q - last_arm_command, -.003, .003)
                if t - since >= 6:
                    change('PLACE', t)
            elif state == 'PLACE':
                dest = np.array([2.48, 0, 1.1 if t - since < 8 else .665])
                q = dest - [2, 0, 1.4]
                last_arm_command += np.clip(q - last_arm_command, -.002, .002)
                if t - since >= 15 and np.linalg.norm(numpy(tool.get_pos()) - dest) < .055:
                    f.scene.sim.rigid_solver.delete_weld_constraint(link_bundle, tool.idx)
                    weld_active = False
                    release_time = t
                    change('FINISH', t)
            elif state == 'FINISH':
                last_arm_command[2] = min(last_arm_command[2] + .003, -.25)
                if t - since >= 8:
                    # Ground truth is read only by this scorer, not by target generation.
                    position = numpy(f.bundle.get_pos())
                    completed = bool(abs(position[0] - 2.48) < .28 and abs(position[1]) < .25 and .52 < position[2] < .65)
                    if completed:
                        completed_at = t
                    change('DONE' if completed else 'WAIT', t)
            elif state == 'DONE' and t - since >= 7:
                break

            if state in ('DRIVE', 'APPROACH'):
                amr_command, last_arm_command = guard_commands(
                    amr_command, last_arm_command, numpy(f.amr.get_dofs_position()),
                    numpy(f.arm.get_dofs_position()), current_bundle_valid, t - last_detection)
            f.amr.control_dofs_position(amr_command)
            f.arm.control_dofs_position(last_arm_command)
            f.scene.step()
            contacts = f.amr.get_contacts(with_entity=f.obstacle)
            if len(contacts['link_a']) > 0:
                contact_steps += 1
            if step % 25 == 0:
                trajectory.append({'time_s': round(t, 2), 'amr_xy': xy.tolist(), 'bundle_detection_xy': None if target_xy is None else target_xy.tolist(), 'detection_age_s': round(t - last_detection, 3), 'state': state})
            if writer is not None and step % 4 == 0:
                title, note = STATES[state]
                frame = compose(f.overview.render()[0], rgb, mask, route, title, t, note, completed)
                writer.append_data(frame)
                frames += 1
                if step % 500 == 0:
                    imageio.imwrite(out / 'preview.png', frame)
    finally:
        if weld_active:
            f.scene.sim.rigid_solver.delete_weld_constraint(link_bundle, tool.idx)
        if writer is not None:
            writer.close()
    result = dict(seed=seed, obstacle=obstacle, completed=completed, duration_s=round(completed_at if completed_at is not None else t, 2),
                  simulation_duration_s=round(t, 2),
                  obstacle_contact_steps=contact_steps, replans=replans, obstacle_detected=obstacle_seen,
                  final_bundle_xyz=numpy(f.bundle.get_pos()).tolist(), release_time_s=release_time,
                  wall_runtime_s=round(time.perf_counter() - runtime_start, 2),
                  video_frames=frames, video_fps=12.5, events=events, trajectory=trajectory)
    (out / f'episode_{seed}_{"obstacle" if obstacle else "normal"}.json').write_text(json.dumps(result, indent=2))
    print(json.dumps({k: v for k, v in result.items() if k not in ('events', 'trajectory')}), flush=True)
    return result
