"""Geometry-only planning. Inputs are perception masks, never object truth."""
import heapq
import numpy as np
from scipy.ndimage import binary_dilation


def inflate(grid, radius):
    yy, xx = np.ogrid[-radius:radius + 1, -radius:radius + 1]
    return binary_dilation(grid, structure=xx * xx + yy * yy <= radius * radius)


def astar(blocked, start, goal):
    start, goal = tuple(start), tuple(goal)
    h, w = blocked.shape
    if any(not (0 <= r < h and 0 <= c < w) for r, c in (start, goal)):
        return []
    if blocked[start] or blocked[goal]:
        return []
    queue = [(0, start)]
    costs, parent = {start: 0}, {}
    while queue:
        _, p = heapq.heappop(queue)
        if p == goal:
            path = [p]
            while p in parent:
                p = parent[p]
                path.append(p)
            return path[::-1]
        for dr, dc in ((0, 1), (0, -1), (1, 0), (-1, 0)):
            q = p[0] + dr, p[1] + dc
            if not (0 <= q[0] < h and 0 <= q[1] < w) or blocked[q]:
                continue
            cost = costs[p] + 1
            if cost < costs.get(q, float('inf')):
                costs[q], parent[q] = cost, p
                heuristic = abs(q[0] - goal[0]) + abs(q[1] - goal[1])
                heapq.heappush(queue, (cost + heuristic, q))
    return []


def grasp_allowed(tool_xyz, target_xyz, age, tolerance=0.09):
    return 0 <= age <= 0.6 and np.linalg.norm(np.array(tool_xyz) - target_xyz) <= tolerance


def facility_map(cal):
    """Prior map of the fixed facility, not ground truth of movable objects."""
    rows, cols = np.indices((cal.height, cal.width))
    a = cal.world_to_pixel((-2.8, 1.4), .395)
    b = cal.world_to_pixel((1.75, -1.4), .395)
    blocked = (cols < a[0]) | (cols > b[0]) | (rows < a[1]) | (rows > b[1])
    scale = 2 * (cal.camera_z - .395) * np.tan(np.deg2rad(cal.fov / 2)) / cal.height
    for x, y in [(1.15, .55), (2.85, .55)]:
        u, v = cal.world_to_pixel((x, y), .395)
        blocked |= ((cols - u) * scale) ** 2 + ((rows - v) * scale) ** 2 <= .45 ** 2
    return blocked


def update_obstacles(memory, mask):
    observed = mask == 3
    return memory | observed if observed.sum() >= 12 else memory.copy()
