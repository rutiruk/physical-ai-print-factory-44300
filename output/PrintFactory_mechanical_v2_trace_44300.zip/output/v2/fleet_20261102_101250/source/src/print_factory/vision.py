"""RGB-only learned perception and calibrated plane intersections."""
from dataclasses import dataclass
import numpy as np
import torch
from torch import nn


@dataclass
class Calibration:
    width: int = 256
    height: int = 256
    camera_z: float = 7.5
    fov: float = 55

    def image_to_world(self, pixel, height=0):
        u, v = pixel
        scale = 2 * (self.camera_z - height) * np.tan(np.deg2rad(self.fov / 2)) / self.height
        return np.array([(u - self.width / 2) * scale, (self.height / 2 - v) * scale])

    def world_to_pixel(self, xy, height=0):
        scale = 2 * (self.camera_z - height) * np.tan(np.deg2rad(self.fov / 2)) / self.height
        return np.array([xy[0] / scale + self.width / 2, self.height / 2 - xy[1] / scale])


def detection(mask, label, age=0, min_pixels=12):
    if not 0 <= age <= 0.6:
        return None
    y, x = np.where(mask == label)
    if len(x) < min_pixels:
        return None
    return np.array([float(np.mean(x)), float(np.mean(y))])


def semantic_labels(compact, index_to_entity, entity_to_class):
    result = np.zeros(compact.shape, np.uint8)
    for index, entity in index_to_entity.items():
        if entity in entity_to_class:
            result[compact == index] = entity_to_class[entity]
    return result


class PixelNet(nn.Module):
    """A compact learned spectral classifier (1x1 CNN); no color thresholds at inference."""
    def __init__(self):
        super().__init__()
        self.layers = nn.Sequential(nn.Conv2d(3, 24, 1), nn.ReLU(), nn.Conv2d(24, 24, 1), nn.ReLU(), nn.Conv2d(24, 4, 1))

    def forward(self, x):
        return self.layers(x)


class Perception:
    def __init__(self, weights, device='cuda'):
        self.device = device
        self.model = PixelNet().to(device)
        checkpoint = torch.load(weights, map_location=device, weights_only=True)
        self.model.load_state_dict(checkpoint['state_dict'])
        self.model.eval()

    @torch.inference_mode()
    def predict(self, rgb):
        x = torch.as_tensor(np.ascontiguousarray(rgb.transpose(2, 0, 1)), device=self.device).float()[None] / 255
        logits = self.model(x)
        probability = logits.softmax(1)
        confidence, mask = probability.max(1)
        mask[confidence < 0.70] = 0
        return mask[0].cpu().numpy().astype(np.uint8)
