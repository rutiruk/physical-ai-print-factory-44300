"""Conventional OSC matching the published policy's low-level action convention.

References: robosuite1.4.1 controllers/osc.py and utils/control_utils.py (MIT).
MuJoCo is used here only for rigid-model kinematics/inverse dynamics, never to step the Genesis world.
"""
import numpy as np
from scipy.spatial.transform import Rotation


def osc_torques(mass,jacobian,position_error,rotation_error,qvel,qerror,bias):
    inv=np.linalg.inv(mass)
    jpos,jori=jacobian[:3],jacobian[3:]
    full=np.linalg.pinv(jacobian@inv@jacobian.T)
    lpos=np.linalg.pinv(jpos@inv@jpos.T)
    lori=np.linalg.pinv(jori@inv@jori.T)
    velocity=jacobian@qvel
    kp=150.
    kd=2*np.sqrt(kp)
    wrench=np.r_[lpos@(kp*np.asarray(position_error)-kd*velocity[:3]),
                 lori@(kp*np.asarray(rotation_error)-kd*velocity[3:])]
    null=np.eye(7)-inv@jacobian.T@full@jacobian
    posture=mass@(10*np.asarray(qerror)-2*np.sqrt(10)*np.asarray(qvel))
    return jacobian.T@wrench+bias+null.T@posture


class ModelOSC:
    def __init__(self,xml,reference):
        import mujoco
        self.mj=mujoco
        self.model=mujoco.MjModel.from_xml_path(str(xml))
        self.data=mujoco.MjData(self.model)
        self.data.qpos[:]=reference['qpos']
        self.names=[f'robot0_joint{i}' for i in range(1,8)]+[f'gripper0_finger_joint{i}' for i in range(1,3)]
        self.qidx=np.array([int(self.model.joint(n).qposadr[0]) for n in self.names])
        self.vidx=np.array([int(self.model.joint(n).dofadr[0]) for n in self.names])
        self.sid=int(self.model.site('gripper0_grip_site').id)
        self.rest=np.array(reference['robot_qpos'])
        self.target_pos=None
        self.target_rot=None
        self.mass=np.empty((self.model.nv,self.model.nv))
        self.jp=np.zeros((3,self.model.nv));self.jr=np.zeros((3,self.model.nv))

    def update(self,q,qvel):
        self.data.qpos[self.qidx]=q
        self.data.qvel[self.vidx]=qvel
        self.mj.mj_forward(self.model,self.data)

    def goal(self,action):
        self.target_pos=self.data.site_xpos[self.sid].copy()+np.asarray(action[:3])*.05
        current=self.data.site_xmat[self.sid].reshape(3,3)
        self.target_rot=Rotation.from_rotvec(np.asarray(action[3:6])*.5).as_matrix()@current

    def torque(self):
        self.mj.mj_fullM(self.model,self.data,self.mass)
        self.mj.mj_jacSite(self.model,self.data,self.jp,self.jr,self.sid)
        idx=self.vidx[:7]
        jac=np.r_[self.jp[:,idx],self.jr[:,idx]]
        mass=self.mass[np.ix_(idx,idx)]
        current=self.data.site_xmat[self.sid].reshape(3,3)
        error=.5*sum(np.cross(current[:,i],self.target_rot[:,i]) for i in range(3))
        return osc_torques(mass,jac,self.target_pos-self.data.site_xpos[self.sid],error,
            self.data.qvel[idx],self.rest-self.data.qpos[self.qidx[:7]],self.data.qfrc_bias[idx])
